export class CreateTicketDto {
  id: number;
  title: string;
  description: string;
  status: string;
  priority: string;
}
