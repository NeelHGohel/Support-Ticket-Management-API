import { Injectable } from '@nestjs/common';
import { CreateTicketDto } from './dto/create-ticket.dto';
import { UpdateTicketDto } from './dto/update-ticket.dto';

@Injectable()
export class TicketsService {
  constructor(private readonly ticketService: TicketsService) {}

  create(createTicketDto: CreateTicketDto) {
    return this.ticketService.create(createTicketDto);
  }

  findAll() {
    return this.ticketService.findAll();
  }

  findOne(id: number) {
    return this.ticketService.findOne(id);
  }

  update(id: number, updateTicketDto: UpdateTicketDto) {
    return this.ticketService.update(id, updateTicketDto);
  }

  remove(id: number) {
    return this.ticketService.remove(id);
  }
}
