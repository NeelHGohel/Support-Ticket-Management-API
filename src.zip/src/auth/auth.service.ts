import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UsersService } from 'src/users/users.service';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
  ) {}
  async validateUser(name: string, password: string) {
    const user = await this.usersService.findByname(name);

    if (!user) {
      throw new UnauthorizedException('User not found');
    }

    return user;
  }

  async login(user: any) {
    const payload = { name: user.name, sub: user.id };
    console.log('Login method called');
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
